'use strict';

const graph_module = require('@arangodb/general-graph');
const vertices = [
  'countries',
  'adm1',
  'adm2',
  'adm3',
  'adm4',
  'cities'
];
const relations = [
  ['inCountry', ['adm1'], ['countries']],
  ['inAdm1', ['adm2'], ['adm1']],
  ['inAdm2', ['adm3'], ['adm2']],
  ['inAdm3', ['adm4'], ['adm3']],
  ['locatedAt', ['cities'], ['countries', 'adm1', 'adm2', 'adm3', 'adm4']]
];

var graph = graph_module._create('world');

vertices.forEach(function (vertexCollection) {
  graph._addVertexCollection(vertexCollection, true);
});

relations.forEach(function (relation) {
  let rel = graph_module._relation(...relation);
  graph._extendEdgeDefinitions(rel);
});
